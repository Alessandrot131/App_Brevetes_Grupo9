package com.example.appbrevete.presentation.appointments.edit

/**
 * Estados del proceso de edición de citas
 */
enum class EditStep {
    LICENSE_SELECTION,
    DATE_TIME_SELECTION,
    CONFIRMATION
}